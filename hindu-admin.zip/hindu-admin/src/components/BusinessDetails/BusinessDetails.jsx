import React from 'react'

const BusinessDetails = () => {
  return (
    <div>
      
    </div>
  )
}

export default BusinessDetails
